create database aula;

use aula;
CREATE TABLE usuario (
    id int NOT NULL AUTO_INCREMENT,
    nome varchar(100) NULL,
    email varchar(100) NULL,
    telefone varchar(50) NULL,
    senha varchar(50) NULL,
    PRIMARY KEY (id)
)
